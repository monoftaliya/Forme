#!/data/data/com.termux/files/usr/bin/sh
cd "$(dirname "$0")" && python -m http.server 8080 --bind 127.0.0.1
